#ifndef UTILS_H
#define UTILS_H

int getInt(const char* prompt);
char* getString(const char* prompt);

#endif
